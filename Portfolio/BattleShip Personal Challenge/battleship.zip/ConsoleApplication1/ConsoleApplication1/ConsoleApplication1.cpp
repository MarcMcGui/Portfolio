// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cstdlib>
#include <string>
#include <conio.h>
#include <stdlib.h>
#include <map>
#include "GameManager.h"

using namespace::std;

int main()
{
    std::cout << "Press any Key to start!\n";
    int num;
    GameManager manager = *new GameManager();
    while (true) {
        
        char input = _getch();
        
        string clear = string(100, '\n');
       
        manager.update(input);
       
    }
   
}
