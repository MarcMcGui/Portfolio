#pragma once
#include <map>
#include <iostream>
#include <string>
#include "ship.h"
#include "ship.cpp"
#include <map>
using namespace::std;

class GameManager
{
public:
    bool cheat;
    ship *ships;
    char grid[10][10];
    int rounds;
    int hits;
    int cursorX;
    int cursorY;
    GameManager();
    ~GameManager();
    void attackShip(char symbol);
    void restart();
    void drawMap();
    void drawMapCheat();
    void drawShip(ship batShip);
    void placeShips();
    void win();
    void lose();
    void update(char input);
    
private:
    
    
};

