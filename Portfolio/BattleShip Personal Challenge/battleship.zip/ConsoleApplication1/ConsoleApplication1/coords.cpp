#include "coords.h"

coords::coords() {
	x = 0;
	y = 0;
}

coords::coords(int x, int y) {
	this->x = x;
	this->y = y;
}