#include "GameManager.h"
#include <iostream>
#include <cstdlib>
#include <string>
#include <conio.h>
#include <map>
#include "ship.cpp"
#include "ship.h"
#include<map>
#include<ctime>__msvc_all_public_headers.hpp
using namespace::std;                   

GameManager::GameManager() {
	cheat = false;
	ships = (new ship[5]
	{
		ship("battleship", 4, 'b'),
		ship("cruiser", 3, 'c'),
		ship("submarine", 3, 's'),
		ship("destroyer", 2, 'd'),
		ship("carrier", 5, 'a')
	});

	cursorX = 0;
	cursorY = 0;
	hits = 0;

	rounds = 35;
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			grid[i][j] = '.';
		}
	}

	placeShips();
	

}

void GameManager::restart() {
	cheat = false;
	rounds = 35;
	hits = 0;
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			grid[i][j] = '.';
		}
	}
	delete[] ships;
	ships = new ship[5]
	{
		ship("battleship", 4, 'b'),
		ship("cruiser", 3, 'c'),
		ship("submarine", 3, 's'),
		ship("destroyer", 2, 'd'),
		ship("carrier", 5, 'a')
	};
	placeShips();
}

GameManager::~GameManager() {
}

void GameManager::drawShip(ship batShip) {
	int pos = 0;
	unsigned seed = time(0);
	srand(seed);
	int startX = rand() % 10;
	int startY = rand() % 10;

	int direction = rand() % 4;
	int endX = startX;
	int endY = startY;
	switch (direction) {
	case 0:
		endY = startY + batShip.length;
		break;
	case 1:
		endX = startX + batShip.length;
		break;
	case 2:
		endY = startY - batShip.length;
		break;
	case 3:
		endX = startX - batShip.length;
		break;
	default:
		break;
	}

	coords* newCoords = batShip.isShipBlocked(*(new coords(startX, startY)), *(new coords(endX, endY)), grid);
	string xVal = grid[startX];
	char startingPoint = xVal.at(startY);

	while (newCoords[0].x != startX || newCoords[0].y != startY) {
		startX = rand() % 10;
		startY = rand() % 10;
		endX = startX;
		endY = startY;
		direction = rand() % 4;
		switch (direction) {
		case 0:
			endY = startY + batShip.length;
			break;
		case 1:
			endX = startX + batShip.length;
			break;
		case 2:
			endY = startY - batShip.length;
			break;
		case 3:
			endX = startX - batShip.length;
			break;
		default:
			break;
		}
		newCoords = batShip.isShipBlocked(*new coords(startX, startY), *new coords(endX, endY), grid);
	}

	if (newCoords != NULL) {
		for (int i = 0; i < batShip.length; i++) {
			grid[newCoords[i].x][newCoords[i].y] = batShip.symbol;
		}
	}



	delete newCoords;  

	
}



void GameManager::placeShips() {
	for (int i = 0; i < 5; i++) {
		drawShip(ships[i]);
	}
}

void GameManager::attackShip(char symbol) {
	for (int i=0; i < 5; i++) {
		if (ships[i].symbol == symbol) {
			ships[i].length -= 1;
		}
	}
}


void GameManager::drawMap() {
	cout << " ";
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if (grid[j][i] == '.' || grid[j][i] != 'O' && grid[j][i] != 'X') {
				if (cursorY == i && cursorX == j) cout << '^';
				else cout << '.';
			}
			else {
				if (cursorY == i && cursorX == j) cout << '[' << grid[j][i] << ']';
				else cout <<  grid[j][i] ;
			}
			if (j == 9) cout << '\n';
			cout << " ";
		}
	}
}

void GameManager::drawMapCheat() {
	cout << " ";
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
				if (cursorY == i && cursorX == j) cout << '[' << grid[j][i] << ']';
				else cout << grid[j][i];
			if (j == 9) cout << '\n';
			cout << " ";
		}
	}
}

void GameManager::lose() {

	std::cout << " YOU LOSE, FAILURE!!!";


	std::cout << "press any key to restart ...\n";

	char input = _getch();


	restart();
}

void GameManager::win() {
	std::cout << " YOU WIN!!!";
		
	std::cout << "press any key to restart ...\n";

	char input = _getch();


	restart();
		
}

//redraws map for every movement/action
void GameManager::update(char input) {
	
	//check input
	switch (input) {
	case 'a': //move left
		if (cursorX > 0) cursorX -= 1;
		break;
	case 's': //move down
		if (cursorY < 9) cursorY += 1;
		break;
	case 'd': //move right
		if (cursorX < 9) cursorX += 1;
		break;
	case 'w': //move up
		if (cursorY > 0) cursorY -= 1;
		break;
	case 'e': //fire
		//if the curor is over a ship location, it's a hit
		if (grid[cursorX][cursorY] != '.' && rounds > 0 && grid[cursorX][cursorY] != 'O') {
			attackShip(grid[cursorX][cursorY]);
			grid[cursorX][cursorY] = 'X';
			
			rounds -= 1;
			hits += 1;
		}
		else if (grid[cursorX][cursorY] == '.' && rounds > 0) {
			grid[cursorX][cursorY] = 'O';
			rounds -= 1;
		}
		break;
	case 'r': //activate cheat mode
		cheat = !cheat;
		break;
	default :
		break;
	}



	std::cout << string(50, '\n');

	//Draws map normally unless "cheat mode" is enabled 
	(!cheat) ? drawMap() : drawMapCheat();

	//Print out the cursor location and the number of rounds left and a list of 
	//ships destroyed 
	std::cout << "location: (" << cursorX << ", " << cursorY << ") rounds left: " << rounds << '\n';
	std::cout << "ships destroyed:" << '\n';
	for (int i = 0; i < 5; i++) {
		if (ships[i].length <= 0) {
			std::cout << ships[i].shipName << '\n';
		}
		else std::cout << "_______" << '\n';
	}
	
	if (rounds <= 0 && hits < 17) {
		lose();
	}
	if (hits >= 17 && rounds > 0) {
		win();
	}
	
}

