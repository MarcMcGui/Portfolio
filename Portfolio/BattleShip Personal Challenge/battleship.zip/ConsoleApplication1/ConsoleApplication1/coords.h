#pragma once
class coords
{

	public:
		int x;
		int y;
		coords();
		coords(int x, int y);


};

